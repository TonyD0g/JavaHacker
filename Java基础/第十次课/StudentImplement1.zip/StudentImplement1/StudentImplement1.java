package The10Class;
import The10Class.Student4;

public class StudentImplement1 {
    public static void main(String [] args){

        Student4 s = new Student4("SAMSUNG", "13811111111");

        s.display();

    }
}
