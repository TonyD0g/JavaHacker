package The10Class;

public class Student4 {
    public String name;
    public String number;
    Student4(String name,String number){
        this.name=name;
        this.number=number;
    }
    public void display(){
        System.out.println("Phone Number="+this.number);
    }
}
