package The10Class;

//设计圆桌类RoundTable，继承类TableInfo，显示圆桌信息。
//圆桌类RoundTable和类TableInfo都放在table包中
public class RoundTableImplement1 {
    public static void main(String [] args){

        TableInfo1 table = new RoundTable1(4, 76, 50);

        table.print();

    }

}
