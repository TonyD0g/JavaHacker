package The10Class;

public class TableInfo1 {
    public int x1;
    public int x2;
    public float x3;
    public void print(){
        System.out.println("Legs="+this.x1);
        System.out.println("Radius="+this.x3);
    }

}
