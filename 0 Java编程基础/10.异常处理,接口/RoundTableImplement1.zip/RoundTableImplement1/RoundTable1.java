package The10Class;
import The10Class.TableInfo1;

public class RoundTable1 extends TableInfo1 {
    RoundTable1(int x1,int x2,float x3){
        this.x1=x1;
        this.x2=x2;
        this.x3=x3;
    }

}
