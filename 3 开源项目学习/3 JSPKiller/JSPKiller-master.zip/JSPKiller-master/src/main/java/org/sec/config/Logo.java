package org.sec.config;

/**
 * 打印Logo
 */
public class Logo {
    public static void PrintLogo() {
        String logo = "   _____               ____        \n" +
                "  /  |  |____________ /_   | ____  \n" +
                " /   |  |\\_  __ \\__  \\ |   |/    \\ \n" +
                "/    ^   /|  | \\// __ \\|   |   |  \\\n" +
                "\\____   | |__|  (____  /___|___|  /\n" +
                "     |__|            \\/         \\/ ";
        System.out.println(logo);
    }
}
