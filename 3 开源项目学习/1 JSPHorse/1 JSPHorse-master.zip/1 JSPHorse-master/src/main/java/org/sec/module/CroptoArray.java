package org.sec.module;

public class CroptoArray {
    public int offset1;
    public int offset2;
}
