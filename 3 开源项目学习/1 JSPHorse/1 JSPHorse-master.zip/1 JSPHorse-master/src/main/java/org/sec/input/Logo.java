package org.sec.input;

public class Logo {
    public static void PrintLogo(){
        System.out.println("　　 へ　　　　　／|\n" +
                "　　/＼7　　　 ∠＿/\n" +
                "　 /　│　　 ／　／\n" +
                "　│　Z ＿,＜　／　　 /`ヽ\n" +
                "　│　　　　　ヽ　　 /　　〉\n" +
                "　 Y　　　　　`　 /　　/\n" +
                "　ｲ●　､　●　　⊂⊃〈　　/\n" +
                "　()　 へ　　　　|　＼〈\n" +
                "　　>ｰ ､_　 ィ　 │ ／／\n" +
                "　 / へ　　 /　ﾉ＜| ＼＼\n" +
                "　 ヽ_ﾉ　　(_／　 │／／\n" +
                "　　7　　　　　　　|／\n" +
                "　　＞―r￣￣~∠--|");
        System.out.println("A JSP Webshell Generator By 4ra1n");
    }
}
